import { motion } from 'framer-motion';
import { Achievement } from '@/shared/types';

interface AchievementBadgeProps {
  achievement: Achievement;
  isNew?: boolean;
}

export default function AchievementBadge({ achievement, isNew = false }: AchievementBadgeProps) {
  const getBadgeIcon = (type: string) => {
    switch (type) {
      case 'daily_goal':
        return '🎯';
      case 'weekly_goal':
        return '🏆';
      case 'streak':
        return '🔥';
      case 'milestone':
        return '⭐';
      default:
        return '💧';
    }
  };

  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'daily_goal':
        return 'from-blue-400 to-cyan-400';
      case 'weekly_goal':
        return 'from-yellow-400 to-orange-400';
      case 'streak':
        return 'from-red-400 to-pink-400';
      case 'milestone':
        return 'from-purple-400 to-blue-400';
      default:
        return 'from-cyan-400 to-blue-400';
    }
  };

  return (
    <motion.div
      className={`inline-flex items-center space-x-2 bg-gradient-to-r ${getBadgeColor(achievement.achievement_type)} px-4 py-2 rounded-full shadow-lg text-white font-semibold text-sm`}
      initial={isNew ? { scale: 0, rotate: -180 } : { scale: 1, rotate: 0 }}
      animate={{ scale: 1, rotate: 0 }}
      transition={isNew ? { 
        type: "spring", 
        stiffness: 300, 
        damping: 20,
        delay: 0.2 
      } : {}}
      whileHover={{ scale: 1.05, y: -2 }}
    >
      <span className="text-lg">{getBadgeIcon(achievement.achievement_type)}</span>
      <span>{achievement.achievement_name}</span>
      <span className="bg-white/20 px-2 py-1 rounded-full text-xs">
        +{achievement.points}
      </span>
      
      {isNew && (
        <>
          <motion.div
            className="absolute -top-1 -right-1 text-yellow-300"
            animate={{
              scale: [1, 1.5, 1],
              rotate: [0, 360]
            }}
            transition={{
              duration: 1,
              repeat: 3
            }}
          >
            ✨
          </motion.div>
          <motion.div
            className="absolute -bottom-1 -left-1 text-white"
            animate={{
              scale: [1, 1.3, 1],
              rotate: [0, -360]
            }}
            transition={{
              duration: 1.2,
              delay: 0.3,
              repeat: 2
            }}
          >
            💫
          </motion.div>
        </>
      )}
    </motion.div>
  );
}
