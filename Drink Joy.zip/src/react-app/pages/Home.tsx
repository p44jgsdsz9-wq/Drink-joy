import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import AppHeader from '@/react-app/components/AppHeader';
import WaterCounter from '@/react-app/components/WaterCounter';
import MotivationalMessage from '@/react-app/components/MotivationalMessage';
import StatsChart from '@/react-app/components/StatsChart';
import AchievementBadge from '@/react-app/components/AchievementBadge';
import WaterDroplet from '@/react-app/components/WaterDroplet';
import DailyHistory from '@/react-app/components/DailyHistory';
import { useWaterTracking } from '@/react-app/hooks/useWaterTracking';

export default function Home() {
  const { dailyIntake, achievements, weeklyStats, loading, error, addCup, resetCups } = useWaterTracking();
  const [messageCounter, setMessageCounter] = useState(0);
  const [celebrationEffect, setCelebrationEffect] = useState(false);

  const handleAddCup = async () => {
    try {
      const oldCount = dailyIntake?.cups_count || 0;
      const goalReached = dailyIntake && oldCount < dailyIntake.daily_goal && (oldCount + 1) >= dailyIntake.daily_goal;
      
      await addCup(1);
      
      // Trigger motivational message
      setMessageCounter(prev => prev + 1);
      
      // Check if goal was reached
      if (goalReached) {
        setCelebrationEffect(true);
        playBubbleSound(); // Play bubble sound when goal is reached
        setTimeout(() => setCelebrationEffect(false), 3000);
      }
    } catch (err) {
      console.error('Failed to add cup:', err);
    }
  };

  const handleResetCups = async () => {
    try {
      await resetCups();
      setMessageCounter(prev => prev + 1);
    } catch (err) {
      console.error('Failed to reset cups:', err);
    }
  };

  // Add some fun sound effects (optional - using Web Audio API)
  const playWaterSound = () => {
    // Create a simple water drop sound using Web Audio API
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.1);
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    } catch (err) {
      console.log('Audio not supported');
    }
  };

  // Create bubble sound effect when goal is reached
  const playBubbleSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Create multiple bubble sounds with different frequencies
      const bubbleFrequencies = [440, 523, 659, 784, 880];
      
      bubbleFrequencies.forEach((freq, index) => {
        setTimeout(() => {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          const filterNode = audioContext.createBiquadFilter();
          
          oscillator.connect(filterNode);
          filterNode.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          // Configure bubble-like sound
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(freq * 0.5, audioContext.currentTime + 0.3);
          
          filterNode.type = 'lowpass';
          filterNode.frequency.setValueAtTime(2000, audioContext.currentTime);
          filterNode.Q.setValueAtTime(1, audioContext.currentTime);
          
          gainNode.gain.setValueAtTime(0, audioContext.currentTime);
          gainNode.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + 0.05);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
          
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.3);
        }, index * 100); // Stagger the bubbles
      });
      
      // Add a final celebratory sound
      setTimeout(() => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(523, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(1047, audioContext.currentTime + 0.5);
        
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
      }, 600);
      
    } catch (err) {
      console.log('Audio not supported');
    }
  };

  useEffect(() => {
    if (messageCounter > 0) {
      playWaterSound();
    }
  }, [messageCounter]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-300 via-cyan-300 to-teal-400 flex items-center justify-center">
        <motion.div 
          className="flex flex-col items-center space-y-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <WaterDroplet size="lg" animate={true} />
          <div className="text-white text-xl font-semibold">Loading your hydration data...</div>
        </motion.div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-300 via-cyan-300 to-teal-400 flex items-center justify-center">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 text-center">
          <div className="text-red-300 text-xl mb-4">⚠️ Oops!</div>
          <div className="text-white">{error}</div>
        </div>
      </div>
    );
  }

  const current = dailyIntake?.cups_count || 0;
  const goal = dailyIntake?.daily_goal || 8;
  const isGoalReached = current >= goal;

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-300 via-cyan-300 to-teal-400 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-10">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Celebration Effects */}
      {celebrationEffect && (
        <motion.div
          className="absolute inset-0 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {Array.from({ length: 50 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-2xl"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              initial={{ scale: 0, rotate: 0 }}
              animate={{
                scale: [0, 1, 0],
                rotate: [0, 360],
                y: [0, -100],
              }}
              transition={{
                duration: 2,
                delay: Math.random() * 0.5,
              }}
            >
              {['🎉', '✨', '💧', '🌟', '🎊'][Math.floor(Math.random() * 5)]}
            </motion.div>
          ))}
        </motion.div>
      )}

      <div className="relative z-10">
        <AppHeader />

        <div className="container mx-auto px-4 pb-8">
          {/* Main Counter */}
          <div className="flex flex-col items-center mb-8">
            <WaterCounter
              current={current}
              goal={goal}
              onAdd={handleAddCup}
            />
            
            {/* Reset Button */}
            <motion.button
              onClick={handleResetCups}
              className="mt-4 bg-gradient-to-r from-red-400 to-pink-500 hover:from-red-500 hover:to-pink-600 text-white font-medium py-2 px-6 rounded-xl shadow-lg transition-all duration-200"
              whileHover={{ scale: 1.05, y: -1 }}
              whileTap={{ scale: 0.95 }}
            >
              ابدأ من الصفر 🔄
            </motion.button>
          </div>

          {/* Goal Reached Banner */}
          {isGoalReached && (
            <motion.div
              className="mb-8 mx-4"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="bg-gradient-to-r from-yellow-400 to-orange-400 text-white p-6 rounded-2xl text-center shadow-xl">
                <div className="text-3xl mb-2">🎉 Goal Achieved! 🎉</div>
                <div className="text-lg font-semibold">
                  You've reached your daily hydration goal!
                </div>
                <div className="text-sm opacity-90 mt-2">
                  Keep drinking to stay perfectly hydrated!
                </div>
              </div>
            </motion.div>
          )}

          {/* Recent Achievements */}
          {achievements.length > 0 && (
            <motion.div
              className="mb-8 mx-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h3 className="text-white text-xl font-bold mb-4 text-center">
                Recent Achievements 🏆
              </h3>
              <div className="flex flex-wrap gap-3 justify-center">
                {achievements.slice(0, 3).map((achievement, index) => (
                  <AchievementBadge
                    key={achievement.id}
                    achievement={achievement}
                    isNew={index === 0}
                  />
                ))}
              </div>
            </motion.div>
          )}

          {/* Daily History */}
          <div className="mx-4 mb-8">
            <DailyHistory />
          </div>

          {/* Weekly Stats */}
          <div className="mx-4">
            <StatsChart data={weeklyStats} />
          </div>

          {/* Daily Challenge */}
          <motion.div
            className="mx-4 mt-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-center shadow-xl border border-white/20">
              <h3 className="text-white text-xl font-bold mb-3">
                Today's Challenge 🎯
              </h3>
              <div className="text-white/90 text-lg mb-4">
                Drink {goal} cups of water today!
              </div>
              <div className="flex justify-center items-center space-x-2">
                <div className="text-white text-sm">Progress:</div>
                <div className="bg-white/20 rounded-full h-3 flex-1 max-w-xs overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full"
                    initial={{ width: "0%" }}
                    animate={{ width: `${Math.min((current / goal) * 100, 100)}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                  />
                </div>
                <div className="text-white text-sm font-bold">
                  {Math.min(Math.round((current / goal) * 100), 100)}%
                </div>
              </div>
            </div>
          </motion.div>

          {/* Footer */}
          <motion.div
            className="text-center mt-12 pb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
          >
            <div className="text-white/70 text-sm">
              Stay hydrated, stay healthy! 💙
            </div>
            <div className="flex justify-center mt-4 space-x-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <WaterDroplet key={i} size="sm" />
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Motivational Messages */}
      <MotivationalMessage trigger={messageCounter} />
    </div>
  );
}
