import { motion } from "framer-motion";
import WaterDroplet from "./WaterDroplet";

export default function AppHeader() {
  return (
    <motion.div 
      className="text-center py-8 px-4"
      initial={{ opacity: 0, y: -30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="flex items-center justify-center space-x-3 mb-2">
        <WaterDroplet size="lg" animate={false} />
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">
            Drink Joy
          </h1>
          <p className="text-white/80 text-sm">by Lujain</p>
        </div>
      </div>
      
      <motion.p 
        className="text-white/70 text-lg font-medium"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        Stay hydrated, stay happy! 💧✨
      </motion.p>
    </motion.div>
  );
}
