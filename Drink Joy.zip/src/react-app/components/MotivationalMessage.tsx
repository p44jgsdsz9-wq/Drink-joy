import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

interface MotivationalMessageProps {
  trigger: number; // Changes when we want to show a new message
}

const messages = [
  "Great! Keep hydrating! 💧",
  "Every sip = more energy ⚡",
  "Your body thanks you! 🌿",
  "Sip for glory! 🌊",
  "You're doing amazing! ✨",
  "Hydration hero! 🦸‍♀️",
  "Water warrior activated! ⚔️",
  "Flowing towards your goal! 🎯",
  "Splash-tastic progress! 🌊",
  "Liquid motivation! 💪",
  "H2-Awesome! 🎉",
  "Refreshingly dedicated! 🌟"
];

export default function MotivationalMessage({ trigger }: MotivationalMessageProps) {
  const [currentMessage, setCurrentMessage] = useState("");
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (trigger > 0) {
      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      setCurrentMessage(randomMessage);
      setIsVisible(true);

      const timer = setTimeout(() => {
        setIsVisible(false);
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [trigger]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed top-1/3 left-1/2 transform -translate-x-1/2 z-50 max-w-sm mx-4"
          initial={{ opacity: 0, y: -50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.8 }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20
          }}
        >
          <div className="bg-gradient-to-r from-cyan-400 to-blue-500 text-white px-6 py-4 rounded-2xl shadow-2xl backdrop-blur-lg">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 0.5, repeat: 1 }}
                className="text-2xl"
              >
                💧
              </motion.div>
              <div className="font-semibold text-lg">{currentMessage}</div>
            </div>
          </div>
          
          {/* Sparkle Effects */}
          <motion.div
            className="absolute -top-2 -right-2 text-yellow-300 text-xl"
            animate={{
              scale: [1, 1.5, 1],
              rotate: [0, 180, 360]
            }}
            transition={{
              duration: 1,
              repeat: 2
            }}
          >
            ✨
          </motion.div>
          
          <motion.div
            className="absolute -bottom-2 -left-2 text-blue-200 text-lg"
            animate={{
              scale: [1, 1.3, 1],
              rotate: [0, -180, -360]
            }}
            transition={{
              duration: 1,
              delay: 0.2,
              repeat: 2
            }}
          >
            💫
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
