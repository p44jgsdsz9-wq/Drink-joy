import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface WaterCounterProps {
  current: number;
  goal: number;
  onAdd: () => void;
}

export default function WaterCounter({ current, goal, onAdd }: WaterCounterProps) {
  const [bubbles, setBubbles] = useState<{ id: number; x: number; delay: number }[]>([]);
  const percentage = Math.min((current / goal) * 100, 100);
  
  useEffect(() => {
    // Create bubbles animation when cup is added
    if (current > 0) {
      const newBubbles = Array.from({ length: 5 }, (_, i) => ({
        id: Date.now() + i,
        x: 20 + Math.random() * 60,
        delay: i * 0.1,
      }));
      setBubbles(newBubbles);
      
      const timer = setTimeout(() => setBubbles([]), 2000);
      return () => clearTimeout(timer);
    }
  }, [current]);

  return (
    <div className="relative flex flex-col items-center">
      {/* Circular Progress Container */}
      <div className="relative w-64 h-64 mb-8">
        {/* Background Circle */}
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke="rgba(255, 255, 255, 0.2)"
            strokeWidth="6"
            fill="none"
            className="backdrop-blur-sm"
          />
        </svg>
        
        {/* Progress Circle */}
        <svg className="absolute inset-0 w-full h-full transform -rotate-90" viewBox="0 0 100 100">
          <motion.circle
            cx="50"
            cy="50"
            r="45"
            stroke={percentage >= 100 ? "url(#completedGradient)" : "url(#progressGradient)"}
            strokeWidth="6"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={`${2 * Math.PI * 45}`}
            strokeDashoffset={`${2 * Math.PI * 45 * (1 - percentage / 100)}`}
            initial={{ strokeDashoffset: 2 * Math.PI * 45 }}
            animate={{ 
              strokeDashoffset: 2 * Math.PI * 45 * (1 - percentage / 100),
              filter: percentage >= 100 ? "drop-shadow(0 0 20px #22C55E)" : "none"
            }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
          <defs>
            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#40E0D0" />
              <stop offset="50%" stopColor="#03A9F4" />
              <stop offset="100%" stopColor="#0288D1" />
            </linearGradient>
            <linearGradient id="completedGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22C55E" />
              <stop offset="50%" stopColor="#16A34A" />
              <stop offset="100%" stopColor="#15803D" />
            </linearGradient>
          </defs>
        </svg>

        {/* Water Fill Animation */}
        <div className="absolute inset-4 rounded-full overflow-hidden bg-gradient-to-b from-transparent to-transparent">
          <motion.div
            className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyan-400 to-cyan-200 opacity-20"
            initial={{ height: "0%" }}
            animate={{ height: `${percentage}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
          
          {/* Animated Wave Effect */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-r from-cyan-300 to-blue-300 opacity-40"
            style={{ height: `${Math.min(percentage, 100)}%` }}
            animate={{
              background: [
                "linear-gradient(90deg, #67E8F9 0%, #3B82F6 50%, #67E8F9 100%)",
                "linear-gradient(90deg, #3B82F6 0%, #67E8F9 50%, #3B82F6 100%)",
              ]
            }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>

        {/* Floating Bubbles */}
        {bubbles.map((bubble) => (
          <motion.div
            key={bubble.id}
            className="absolute w-2 h-2 bg-white rounded-full opacity-60"
            style={{
              left: `${bubble.x}%`,
              bottom: `${percentage * 0.8}%`,
            }}
            initial={{ y: 0, opacity: 0.6, scale: 1 }}
            animate={{ y: -100, opacity: 0, scale: 0.5 }}
            transition={{
              duration: 2,
              delay: bubble.delay,
              ease: "easeOut",
            }}
          />
        ))}

        {/* Counter Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <motion.div 
            className="text-4xl font-bold mb-2"
            key={current}
            initial={{ scale: 1 }}
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 0.3 }}
          >
            {current}
          </motion.div>
          <div className="text-lg opacity-80">/ {goal} أكواب</div>
          {current >= goal ? (
            <motion.div 
              className="text-sm mt-1 text-green-300 font-semibold flex items-center gap-1"
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.2, 1] }}
              transition={{ duration: 0.5 }}
            >
              <span>🎉</span>
              <span>مكتمل!</span>
              <span>🎉</span>
            </motion.div>
          ) : (
            <div className="text-sm opacity-60 mt-1">
              {percentage.toFixed(0)}% مكتمل
            </div>
          )}
        </div>
      </div>

      {/* Add Cup Button */}
      <motion.button
        onClick={onAdd}
        className={`font-bold py-4 px-8 rounded-2xl shadow-xl transition-all duration-200 text-lg ${
          current >= goal
            ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
            : "bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white"
        }`}
        whileHover={{ scale: 1.05, y: -2 }}
        whileTap={{ scale: 0.95 }}
        animate={{
          boxShadow: current >= goal 
            ? "0 10px 30px rgba(34, 197, 94, 0.4)" 
            : "0 10px 20px rgba(0, 0, 0, 0.2)"
        }}
      >
        {current >= goal ? "أضف المزيد 🌟" : "أضف كوب 💧"}
      </motion.button>
    </div>
  );
}
