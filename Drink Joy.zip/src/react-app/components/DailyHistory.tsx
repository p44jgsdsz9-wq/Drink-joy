import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

interface DailyRecord {
  date: string;
  cups: number;
  goal: number;
  improvement?: number;
}

interface DailyHistoryProps {
  className?: string;
}

export default function DailyHistory({ className = "" }: DailyHistoryProps) {
  const [history, setHistory] = useState<DailyRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await fetch('/api/stats/weekly');
      if (!response.ok) throw new Error('Failed to fetch history');
      const data = await response.json();
      
      const records: DailyRecord[] = data.map((item: any, index: number) => {
        const record: DailyRecord = {
          date: item.intake_date,
          cups: item.cups_count,
          goal: item.daily_goal,
        };
        
        // Calculate improvement from previous day
        if (index < data.length - 1) {
          const previousCups = data[index + 1].cups_count;
          record.improvement = record.cups - previousCups;
        }
        
        return record;
      });
      
      setHistory(records);
    } catch (err) {
      console.error('Failed to fetch history:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString + 'T00:00:00'); // Ensure local timezone interpretation
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const dateOnly = dateString; // Already in YYYY-MM-DD format
    const todayOnly = today.toLocaleDateString('en-CA'); // YYYY-MM-DD format in local timezone
    const yesterdayOnly = yesterday.toLocaleDateString('en-CA');
    
    if (dateOnly === todayOnly) {
      return 'اليوم';
    } else if (dateOnly === yesterdayOnly) {
      return 'أمس';
    } else {
      return date.toLocaleDateString('ar-SA', { 
        weekday: 'long',
        month: 'short',
        day: 'numeric'
      });
    }
  };

  const getProgressColor = (cups: number, goal: number) => {
    const percentage = (cups / goal) * 100;
    if (percentage >= 100) return 'from-green-400 to-emerald-500';
    if (percentage >= 75) return 'from-blue-400 to-cyan-500';
    if (percentage >= 50) return 'from-yellow-400 to-orange-400';
    return 'from-red-400 to-pink-500';
  };

  const getImprovementIcon = (improvement?: number) => {
    if (!improvement) return null;
    if (improvement > 0) return '📈';
    if (improvement < 0) return '📉';
    return '➡️';
  };

  const getImprovementText = (improvement?: number) => {
    if (!improvement) return '';
    if (improvement > 0) return `+${improvement} كوب`;
    if (improvement < 0) return `${improvement} كوب`;
    return 'نفس العدد';
  };

  const getImprovementColor = (improvement?: number) => {
    if (!improvement) return 'text-white/60';
    if (improvement > 0) return 'text-green-300';
    if (improvement < 0) return 'text-red-300';
    return 'text-white/60';
  };

  if (loading) {
    return (
      <div className={`bg-white/10 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/20 ${className}`}>
        <div className="text-white text-center">جاري التحميل...</div>
      </div>
    );
  }

  if (history.length === 0) {
    return (
      <div className={`bg-white/10 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/20 ${className}`}>
        <h3 className="text-white text-xl font-bold mb-4 text-center">
          📅 تاريخ شربك للماء
        </h3>
        <div className="text-white/60 text-center">
          ابدأ بشرب الماء لترى تاريخك!
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      className={`bg-white/10 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/20 ${className}`}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
    >
      <h3 className="text-white text-xl font-bold mb-6 text-center">
        📅 تاريخ شربك للماء
      </h3>
      
      <div className="space-y-3">
        {history.map((record, index) => {
          const percentage = Math.min((record.cups / record.goal) * 100, 100);
          const isGoalReached = record.cups >= record.goal;
          
          return (
            <motion.div
              key={record.date}
              className="bg-white/5 rounded-xl p-4 hover:bg-white/10 transition-all"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className="text-white font-semibold">
                    {formatDate(record.date)}
                  </span>
                  {isGoalReached && (
                    <span className="text-xl">✅</span>
                  )}
                </div>
                <div className="text-white/80 text-sm">
                  {record.cups} / {record.goal} أكواب
                </div>
              </div>
              
              {/* Progress Bar */}
              <div className="relative w-full h-3 bg-white/10 rounded-full overflow-hidden mb-2">
                <motion.div
                  className={`h-full bg-gradient-to-r ${getProgressColor(record.cups, record.goal)} rounded-full`}
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                />
              </div>
              
              {/* Stats Row */}
              <div className="flex items-center justify-between text-xs">
                <div className="text-white/70">
                  {percentage.toFixed(0)}% مكتمل
                </div>
                
                {record.improvement !== undefined && (
                  <div className={`flex items-center space-x-1 space-x-reverse ${getImprovementColor(record.improvement)}`}>
                    <span>{getImprovementIcon(record.improvement)}</span>
                    <span>{getImprovementText(record.improvement)}</span>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
      
      {/* Summary Section */}
      <motion.div
        className="mt-6 pt-4 border-t border-white/20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="bg-white/5 rounded-lg p-3">
            <div className="text-white/60 text-xs mb-1">أيام الإنجاز</div>
            <div className="text-white text-2xl font-bold">
              {history.filter(r => r.cups >= r.goal).length}
            </div>
          </div>
          <div className="bg-white/5 rounded-lg p-3">
            <div className="text-white/60 text-xs mb-1">متوسط الأكواب</div>
            <div className="text-white text-2xl font-bold">
              {history.length > 0 
                ? (history.reduce((sum, r) => sum + r.cups, 0) / history.length).toFixed(1)
                : '0'
              }
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
