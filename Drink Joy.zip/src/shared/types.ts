import z from "zod";

export const DailyIntakeSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  intake_date: z.string(),
  cups_count: z.number(),
  daily_goal: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const WaterLogSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  cups_added: z.number(),
  logged_at: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const AchievementSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  achievement_type: z.string(),
  achievement_name: z.string(),
  earned_at: z.string(),
  points: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const UserSettingsSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  daily_goal: z.number(),
  reminder_interval: z.number(),
  theme: z.string(),
  sound_enabled: z.boolean(),
  notifications_enabled: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type DailyIntake = z.infer<typeof DailyIntakeSchema>;
export type WaterLog = z.infer<typeof WaterLogSchema>;
export type Achievement = z.infer<typeof AchievementSchema>;
export type UserSettings = z.infer<typeof UserSettingsSchema>;

export const AddCupRequestSchema = z.object({
  cups: z.number().min(1).default(1),
});

export type AddCupRequest = z.infer<typeof AddCupRequestSchema>;

export const UpdateSettingsRequestSchema = z.object({
  daily_goal: z.number().min(1).max(20).optional(),
  reminder_interval: z.number().min(15).max(480).optional(),
  theme: z.enum(['light', 'dark']).optional(),
  sound_enabled: z.boolean().optional(),
  notifications_enabled: z.boolean().optional(),
});

export type UpdateSettingsRequest = z.infer<typeof UpdateSettingsRequestSchema>;
