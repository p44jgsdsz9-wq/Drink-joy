import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { motion } from 'framer-motion';

interface StatsData {
  date: string;
  cups: number;
  goal: number;
}

interface StatsChartProps {
  data: StatsData[];
  className?: string;
}

export default function StatsChart({ data, className = "" }: StatsChartProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white/90 backdrop-blur-lg p-3 rounded-lg shadow-xl border border-white/20">
          <p className="text-gray-800 font-medium">{formatDate(label)}</p>
          <p className="text-blue-600">
            Cups: {payload[0].value} / {payload[0].payload.goal}
          </p>
          <p className="text-gray-600 text-sm">
            {Math.round((payload[0].value / payload[0].payload.goal) * 100)}% of goal
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <motion.div 
      className={`bg-white/10 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/20 ${className}`}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
    >
      <h3 className="text-white text-xl font-bold mb-4 text-center">
        Weekly Progress 📊
      </h3>
      
      {data.length > 0 ? (
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="waterGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#40E0D0" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#40E0D0" stopOpacity={0.2}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="date" 
              tickFormatter={formatDate}
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'white', fontSize: 12 }}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'white', fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="cups"
              stroke="#40E0D0"
              strokeWidth={3}
              fill="url(#waterGradient)"
              fillOpacity={1}
            />
          </AreaChart>
        </ResponsiveContainer>
      ) : (
        <div className="h-48 flex items-center justify-center text-white/60">
          <div className="text-center">
            <div className="text-4xl mb-2">📈</div>
            <p>Start drinking to see your progress!</p>
          </div>
        </div>
      )}
      
      <div className="flex justify-center mt-4 space-x-4 text-sm text-white/80">
        <div className="flex items-center space-x-1">
          <div className="w-3 h-3 bg-cyan-400 rounded-full"></div>
          <span>Daily Cups</span>
        </div>
      </div>
    </motion.div>
  );
}
