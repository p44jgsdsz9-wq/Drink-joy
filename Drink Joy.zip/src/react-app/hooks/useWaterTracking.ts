import { useState, useEffect, useCallback } from 'react';
import { DailyIntake, Achievement } from '@/shared/types';

export function useWaterTracking() {
  const [dailyIntake, setDailyIntake] = useState<DailyIntake | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [weeklyStats, setWeeklyStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTodayIntake = useCallback(async () => {
    try {
      const response = await fetch('/api/intake/today');
      if (!response.ok) throw new Error('Failed to fetch today\'s intake');
      const data = await response.json();
      setDailyIntake(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    }
  }, []);

  const fetchAchievements = useCallback(async () => {
    try {
      const response = await fetch('/api/achievements');
      if (!response.ok) throw new Error('Failed to fetch achievements');
      const data = await response.json();
      setAchievements(data);
    } catch (err) {
      console.error('Failed to fetch achievements:', err);
    }
  }, []);

  const fetchWeeklyStats = useCallback(async () => {
    try {
      const response = await fetch('/api/stats/weekly');
      if (!response.ok) throw new Error('Failed to fetch weekly stats');
      const data = await response.json();
      const formattedData = data.map((item: any) => ({
        date: item.intake_date,
        cups: item.cups_count,
        goal: item.daily_goal
      }));
      setWeeklyStats(formattedData);
    } catch (err) {
      console.error('Failed to fetch weekly stats:', err);
    }
  }, []);

  const addCup = useCallback(async (cups: number = 1) => {
    try {
      const response = await fetch('/api/intake/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ cups }),
      });
      
      if (!response.ok) throw new Error('Failed to add cup');
      
      const data = await response.json();
      setDailyIntake(data);
      
      // Refresh achievements and stats
      await fetchAchievements();
      await fetchWeeklyStats();
      
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    }
  }, [fetchAchievements, fetchWeeklyStats]);

  const resetCups = useCallback(async () => {
    try {
      const response = await fetch('/api/intake/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) throw new Error('Failed to reset cups');
      
      const data = await response.json();
      setDailyIntake(data);
      
      // Refresh stats
      await fetchWeeklyStats();
      
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    }
  }, [fetchWeeklyStats]);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        await Promise.all([
          fetchTodayIntake(),
          fetchAchievements(),
          fetchWeeklyStats(),
        ]);
      } catch (err) {
        console.error('Failed to load initial data:', err);
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, [fetchTodayIntake, fetchAchievements, fetchWeeklyStats]);

  return {
    dailyIntake,
    achievements,
    weeklyStats,
    loading,
    error,
    addCup,
    resetCups,
    refreshData: () => {
      fetchTodayIntake();
      fetchAchievements();
      fetchWeeklyStats();
    }
  };
}
