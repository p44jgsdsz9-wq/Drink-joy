
DROP INDEX idx_achievements_user;
DROP INDEX idx_water_logs_user_date;
DROP INDEX idx_daily_intake_user_date;
DROP TABLE user_settings;
DROP TABLE achievements;
DROP TABLE water_logs;
DROP TABLE daily_intake;
