import { Hono } from "hono";
import { cors } from "hono/cors";
import { DailyIntake, UserSettings, AddCupRequestSchema, UpdateSettingsRequestSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

const DEMO_USER_ID = "demo-user";

// Get today's water intake
app.get("/api/intake/today", async (c) => {
  const today = new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD format in local timezone
  
  const result = await c.env.DB.prepare(`
    SELECT * FROM daily_intake 
    WHERE user_id = ? AND intake_date = ?
  `).bind(DEMO_USER_ID, today).first() as DailyIntake | null;

  if (!result) {
    const newIntake = await c.env.DB.prepare(`
      INSERT INTO daily_intake (user_id, intake_date, cups_count, daily_goal)
      VALUES (?, ?, 0, 8)
      RETURNING *
    `).bind(DEMO_USER_ID, today).first() as DailyIntake;
    
    return c.json(newIntake);
  }

  return c.json(result);
});

// Add cups
app.post("/api/intake/add", async (c) => {
  try {
    const body = AddCupRequestSchema.parse(await c.req.json());
    const today = new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD format in local timezone
    const now = new Date().toISOString();

    // Get or create today's intake
    let dailyIntake = await c.env.DB.prepare(`
      SELECT * FROM daily_intake 
      WHERE user_id = ? AND intake_date = ?
    `).bind(DEMO_USER_ID, today).first() as DailyIntake | null;

    if (!dailyIntake) {
      dailyIntake = await c.env.DB.prepare(`
        INSERT INTO daily_intake (user_id, intake_date, cups_count, daily_goal)
        VALUES (?, ?, 0, 8)
        RETURNING *
      `).bind(DEMO_USER_ID, today).first() as DailyIntake;
    }

    // Update cups count
    const newCount = dailyIntake.cups_count + body.cups;
    await c.env.DB.prepare(`
      UPDATE daily_intake 
      SET cups_count = ?, updated_at = ?
      WHERE id = ?
    `).bind(newCount, now, dailyIntake.id).run();

    // Log the water intake
    await c.env.DB.prepare(`
      INSERT INTO water_logs (user_id, cups_added, logged_at)
      VALUES (?, ?, ?)
    `).bind(DEMO_USER_ID, body.cups, now).run();

    // Check for achievements
    if (newCount >= dailyIntake.daily_goal && dailyIntake.cups_count < dailyIntake.daily_goal) {
      await c.env.DB.prepare(`
        INSERT INTO achievements (user_id, achievement_type, achievement_name, points)
        VALUES (?, 'daily_goal', 'Daily Goal Achieved!', 10)
      `).bind(DEMO_USER_ID).run();
    }

    const updatedIntake = await c.env.DB.prepare(`
      SELECT * FROM daily_intake 
      WHERE user_id = ? AND intake_date = ?
    `).bind(DEMO_USER_ID, today).first() as DailyIntake;

    return c.json(updatedIntake);
  } catch (error) {
    return c.json({ error: "Invalid request" }, 400);
  }
});

// Get weekly stats
app.get("/api/stats/weekly", async (c) => {
  const today = new Date();
  const weekAgo = new Date(today);
  weekAgo.setDate(today.getDate() - 7);

  const results = await c.env.DB.prepare(`
    SELECT * FROM daily_intake 
    WHERE user_id = ? AND intake_date >= ?
    ORDER BY intake_date DESC
  `).bind(DEMO_USER_ID, weekAgo.toLocaleDateString('en-CA')).all();

  return c.json(results.results);
});

// Get achievements
app.get("/api/achievements", async (c) => {
  const results = await c.env.DB.prepare(`
    SELECT * FROM achievements 
    WHERE user_id = ?
    ORDER BY earned_at DESC
    LIMIT 10
  `).bind(DEMO_USER_ID).all();

  return c.json(results.results);
});

// Get user settings
app.get("/api/settings", async (c) => {
  let settings = await c.env.DB.prepare(`
    SELECT * FROM user_settings 
    WHERE user_id = ?
  `).bind(DEMO_USER_ID).first() as UserSettings | null;

  if (!settings) {
    settings = await c.env.DB.prepare(`
      INSERT INTO user_settings (user_id, daily_goal, reminder_interval, theme, sound_enabled, notifications_enabled)
      VALUES (?, 8, 60, 'light', 1, 1)
      RETURNING *
    `).bind(DEMO_USER_ID).first() as UserSettings;
  }

  return c.json(settings);
});

// Reset today's water intake
app.post("/api/intake/reset", async (c) => {
  const today = new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD format in local timezone
  const now = new Date().toISOString();

  // Reset today's intake to 0
  await c.env.DB.prepare(`
    UPDATE daily_intake 
    SET cups_count = 0, updated_at = ?
    WHERE user_id = ? AND intake_date = ?
  `).bind(now, DEMO_USER_ID, today).run();

  // Get the updated intake
  const updatedIntake = await c.env.DB.prepare(`
    SELECT * FROM daily_intake 
    WHERE user_id = ? AND intake_date = ?
  `).bind(DEMO_USER_ID, today).first() as DailyIntake;

  return c.json(updatedIntake);
});

// Update user settings
app.put("/api/settings", async (c) => {
  try {
    const body = UpdateSettingsRequestSchema.parse(await c.req.json());
    const now = new Date().toISOString();

    // Get existing settings
    let settings = await c.env.DB.prepare(`
      SELECT * FROM user_settings 
      WHERE user_id = ?
    `).bind(DEMO_USER_ID).first() as UserSettings | null;

    if (!settings) {
      settings = await c.env.DB.prepare(`
        INSERT INTO user_settings (user_id, daily_goal, reminder_interval, theme, sound_enabled, notifications_enabled)
        VALUES (?, 8, 60, 'light', 1, 1)
        RETURNING *
      `).bind(DEMO_USER_ID).first() as UserSettings;
    }

    // Update with provided values
    const updateData = {
      daily_goal: body.daily_goal ?? settings.daily_goal,
      reminder_interval: body.reminder_interval ?? settings.reminder_interval,
      theme: body.theme ?? settings.theme,
      sound_enabled: body.sound_enabled ?? settings.sound_enabled,
      notifications_enabled: body.notifications_enabled ?? settings.notifications_enabled,
    };

    const updatedSettings = await c.env.DB.prepare(`
      UPDATE user_settings 
      SET daily_goal = ?, reminder_interval = ?, theme = ?, sound_enabled = ?, notifications_enabled = ?, updated_at = ?
      WHERE user_id = ?
      RETURNING *
    `).bind(
      updateData.daily_goal,
      updateData.reminder_interval,
      updateData.theme,
      updateData.sound_enabled,
      updateData.notifications_enabled,
      now,
      DEMO_USER_ID
    ).first();

    return c.json(updatedSettings);
  } catch (error) {
    return c.json({ error: "Invalid request" }, 400);
  }
});

export default app;
