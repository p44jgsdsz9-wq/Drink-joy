import { motion } from "framer-motion";

interface WaterDropletProps {
  className?: string;
  animate?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export default function WaterDroplet({ className = "", animate = false, size = 'md' }: WaterDropletProps) {
  const sizeClasses = {
    sm: 'w-6 h-8',
    md: 'w-8 h-10',
    lg: 'w-12 h-16'
  };

  const dropletVariants = {
    idle: {
      scale: 1,
      rotate: 0,
      opacity: 1,
    },
    bounce: {
      scale: [1, 1.2, 1],
      rotate: [0, 5, -5, 0],
      opacity: [1, 0.8, 1],
      transition: {
        duration: 0.6,
        ease: "easeInOut" as const
      }
    },
    float: {
      y: [0, -10, 0],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut" as const
      }
    }
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} ${className} flex items-center justify-center`}
      variants={dropletVariants}
      animate={animate ? "bounce" : "idle"}
      whileHover="float"
    >
      <svg
        viewBox="0 0 24 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-lg"
      >
        <path
          d="M12 0C12 0 24 12 24 20C24 26.6274 18.6274 32 12 32C5.37258 32 0 26.6274 0 20C0 12 12 0 12 0Z"
          fill="url(#dropletGradient)"
        />
        <circle
          cx="8"
          cy="18"
          r="2"
          fill="rgba(255, 255, 255, 0.3)"
        />
        <defs>
          <linearGradient
            id="dropletGradient"
            x1="12"
            y1="0"
            x2="12"
            y2="32"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#40E0D0" />
            <stop offset="0.5" stopColor="#03A9F4" />
            <stop offset="1" stopColor="#0288D1" />
          </linearGradient>
        </defs>
      </svg>
    </motion.div>
  );
}
